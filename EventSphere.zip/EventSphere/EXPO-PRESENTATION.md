# EventSphere — Expo Presentation

## 60-second introduction
"Good morning. Our project is EventSphere, a cloud-native event discovery and ticketing platform. It helps people discover live events, book tickets, and receive unique QR tickets. Organizers can publish events, track sales, and verify tickets. We designed the interface around a premium purple neon concert theme, while the backend uses a transactional database and containerized services."

## Demo flow
1. Show the homepage and explain the hero, event cards, filters and responsive design.
2. Sign in using `attendee@eventsphere.local` / `ExpoDemo123!`.
3. Open an event, book 1–2 tickets, and show the generated QR code.
4. Open My Tickets and show ticket history.
5. Sign out and sign in using `organizer@eventsphere.local` / `ExpoDemo123!`.
6. Open Studio to show event creation and summary cards.
7. Open Grafana at `http://localhost:3001`, login `admin` / `admin` for the local demo, and show API requests, booking counter, and process metrics.
8. Explain that Docker Compose runs services together and Kubernetes runs multiple frontend/API replicas with probes and persistent storage.

## Architecture explanation
Browser → Nginx/React frontend → Express REST API → PostgreSQL.
The API exposes Prometheus metrics. Prometheus scrapes `/metrics`, and Grafana visualizes them. Docker packages the frontend and API into images. GitHub Actions builds/checks the app. Kubernetes deployments and Helm templates define repeatable deployment, replicas, probes and resources.

## What makes it cloud-native?
- Containerized frontend and backend
- Stateless API that can scale horizontally
- Persistent database storage
- Health/readiness/liveness probes
- Metrics endpoint and monitoring dashboard
- Automated build pipeline and Helm-based deployment

## Future improvements
Payment gateway integration, email notifications, event image uploads, password reset, Redis caching, autoscaling, alerts, managed PostgreSQL, TLS ingress, and audit logs.
