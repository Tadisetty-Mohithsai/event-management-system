# EventSphere — Cloud-Native Event Management & Ticketing

A full-stack expo project inspired by the uploaded purple/neon concert design. Includes a React + Vite frontend, Express API, PostgreSQL, JWT authentication, ticket booking, QR tickets, Docker Compose, Kubernetes manifests, Helm chart, GitHub Actions CI/CD, and Prometheus/Grafana monitoring.

## Features
- Purple neon concert landing page with search and genre filters
- Event detail and booking flow
- User registration/login with JWT
- Database-backed bookings and inventory protection in a transaction
- Unique ticket code and QR code for each booking
- Organizer/admin event creation and ticket validation endpoints
- Prometheus `/metrics` endpoint and Grafana dashboard
- Docker Compose local stack
- Kubernetes manifests and Helm chart
- GitHub Actions build/publish workflow

## Requirements
- Docker Desktop with Compose (recommended for the expo)
- For Kubernetes: a cluster such as Docker Desktop Kubernetes, Minikube, or a cloud Kubernetes cluster
- For cloud deployment: container registry and Kubernetes cluster credentials

## Run locally (recommended)
1. Extract this ZIP and open a terminal in the project root.
2. Copy `.env.example` to `.env` and change `JWT_SECRET` before sharing/deploying.
3. Run:
   ```bash
   docker compose up --build -d
   ```
4. Open **http://localhost:8080**.
5. API health check: **http://localhost:4000/health**
6. Prometheus: **http://localhost:9090**
7. Grafana: **http://localhost:3001** (default local demo login: `admin` / `admin`; change before any public deployment).

Demo accounts are created only if `SEED_DEMO=true`:
- Admin/organizer: `organizer@eventsphere.local` / `ExpoDemo123!`
- Attendee: `attendee@eventsphere.local` / `ExpoDemo123!`

## Local development without Docker
Terminal 1:
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```
Terminal 2:
```bash
cd frontend
npm install
npm run dev
```
Set `VITE_API_URL=http://localhost:4000/api` in `frontend/.env` if needed. The backend requires PostgreSQL; easiest is to run only the database with `docker compose up -d db`.

## Important security notes
This is an educational demo foundation, not a production-certified ticketing/payment system. It does not charge real money. Never put real secrets in source control. Before a public cloud deployment, change all default credentials, set a strong `JWT_SECRET`, configure TLS/Ingress, use managed secrets, enable database backups, configure CORS to your domain, and use a managed database or persistent storage. Do not expose Grafana or Prometheus publicly without authentication and network restrictions.

## API overview
- `GET /health`
- `GET /metrics`
- `GET /api/events`
- `GET /api/events/:id`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me` (Bearer token)
- `GET /api/bookings/mine` (Bearer token)
- `POST /api/bookings` (Bearer token)
- `POST /api/bookings/:id/check-in` (organizer/admin token)
- `POST /api/events` (organizer/admin token)
- `GET /api/admin/summary` (organizer/admin token)

## Deploy to Kubernetes
1. Build and push images to your container registry:
   ```bash
   docker build -t YOUR_REGISTRY/eventsphere-api:1.0.0 ./backend
   docker build -t YOUR_REGISTRY/eventsphere-web:1.0.0 ./frontend
   docker push YOUR_REGISTRY/eventsphere-api:1.0.0
   docker push YOUR_REGISTRY/eventsphere-web:1.0.0
   ```
2. Update image repositories/tags and secret values in `k8s/` or `helm/eventsphere/values.yaml`.
3. Apply Kubernetes resources:
   ```bash
   kubectl apply -f k8s/namespace.yaml
   kubectl apply -f k8s/secret.example.yaml
   kubectl apply -f k8s/postgres.yaml
   kubectl apply -f k8s/backend.yaml
   kubectl apply -f k8s/frontend.yaml
   ```
   `secret.example.yaml` is a template. Replace placeholder credentials and do not commit real secrets.
4. Or install the Helm chart after editing values:
   ```bash
   helm upgrade --install eventsphere ./helm/eventsphere -n eventsphere --create-namespace
   ```
5. For a local cluster, access via:
   ```bash
   kubectl port-forward svc/eventsphere-frontend 8080:80 -n eventsphere
   ```
6. Configure a real Ingress, TLS certificate, registry pull secret, persistent volume/storage class, and external database for a public cloud deployment.

## CI/CD
GitHub Actions workflow `.github/workflows/ci.yml` runs frontend/backend checks and builds Docker images. Add repository secrets `REGISTRY_USERNAME` and `REGISTRY_PASSWORD` and set the registry/image names before enabling pushes. The default workflow builds on pull requests and pushes; registry publishing is intentionally guarded by configuration.

## Expo walkthrough
1. Open the homepage and explain the neon event discovery interface.
2. Search “Pulse” or filter by genre.
3. Sign in with attendee demo credentials.
4. Book tickets and show the generated QR ticket in “My Tickets”.
5. Sign in as organizer in a separate browser session to show event/admin endpoints.
6. Open Grafana and explain request rate, API health, and container metrics (application metrics are included; container-level metrics need cAdvisor/node-exporter if desired).
7. Explain horizontal scaling: frontend and backend are stateless; PostgreSQL stores events/bookings; Kubernetes readiness/liveness probes manage restarts.
