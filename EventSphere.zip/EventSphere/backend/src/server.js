import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import pg from 'pg';
import QRCode from 'qrcode';
import { randomUUID } from 'node:crypto';
import client from 'prom-client';

const { Pool } = pg;
const app = express();
const port = Number(process.env.PORT || 4000);
const jwtSecret = process.env.JWT_SECRET || 'local_demo_change_me_please';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const register = new client.Registry();
client.collectDefaultMetrics({ register });
const httpCounter = new client.Counter({ name: 'eventsphere_http_requests_total', help: 'HTTP requests served', labelNames: ['method','route','status'], registers: [register] });
const bookingCounter = new client.Counter({ name: 'eventsphere_bookings_created_total', help: 'Successful bookings created', registers: [register] });

app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: (process.env.CORS_ORIGIN || 'http://localhost:5173').split(','), credentials: false }));
app.use(express.json({ limit: '1mb' }));
app.use((req,res,next) => {
  res.on('finish', () => httpCounter.inc({ method: req.method, route: req.route?.path || req.path, status: String(res.statusCode) }));
  next();
});
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 80, standardHeaders: true, legacyHeaders: false }));

const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
const safeUser = u => ({ id: u.id, name: u.name, email: u.email, role: u.role });
const signToken = u => jwt.sign(safeUser(u), jwtSecret, { expiresIn: '8h' });
function auth(req,res,next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  try { if (!token) throw new Error('missing'); req.user = jwt.verify(token, jwtSecret); next(); }
  catch { res.status(401).json({ error: 'Please sign in to continue.' }); }
}
function roles(...allowed) {
  return (req,res,next) => allowed.includes(req.user?.role) ? next() : res.status(403).json({ error: 'You do not have permission to do that.' });
}
const eventSelect = `SELECT id,title,artist,description,category,venue,city,event_date,price,capacity,available,image_url,accent FROM events`;
async function seed() {
  const exists = await pool.query('SELECT COUNT(*)::int AS n FROM events');
  if (exists.rows[0].n === 0) {
    const data = [
      ['Nova Pulse','Nova Pulse','A cinematic arena show with lasers, immersive visuals and thunderous live drums.','Electronic','Skyline Arena','Hyderabad','2027-02-20T19:30:00+05:30',1499,120,'https://images.unsplash.com/photo-1506157786151-b8491531f063?auto=format&fit=crop&w=1200&q=85','#a855f7'],
      ['Luna Vibe','Luna Vibe','An intimate sunset session blending indie pop, live instruments and golden-hour energy.','Indie','Riverside Grounds','Hyderabad','2027-02-28T17:00:00+05:30',999,80,'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?auto=format&fit=crop&w=1200&q=85','#fb923c'],
      ['Echo Horizon','Echo Horizon','A high-energy dance experience with breathtaking choreography and a world-class soundscape.','Dance','Aurora Convention Hall','Bengaluru','2027-03-06T18:30:00+05:30',1299,100,'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=1200&q=85','#22d3ee'],
      ['Midnight Frequency','Midnight Frequency','Deep house, glowing visuals and a late-night journey for electronic music lovers.','Electronic','The Foundry','Pune','2027-03-13T20:00:00+05:30',1799,150,'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?auto=format&fit=crop&w=1200&q=85','#ec4899'],
      ['Acoustic Skies','Acoustic Skies','A stripped-back acoustic evening featuring intimate performances and stories behind the songs.','Acoustic','The Courtyard','Chennai','2027-03-21T18:00:00+05:30',799,70,'https://images.unsplash.com/photo-1516280440614-37939bbacd81?auto=format&fit=crop&w=1200&q=85','#fbbf24'],
      ['Afterglow Festival','Afterglow Festival','A full-day celebration of music, art installations, street food and creative culture.','Festival','Open Air Park','Hyderabad','2027-04-04T15:00:00+05:30',2199,250,'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?auto=format&fit=crop&w=1200&q=85','#818cf8']
    ];
    for (const e of data) await pool.query('INSERT INTO events(title,artist,description,category,venue,city,event_date,price,capacity,available,image_url,accent) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$9,$10,$11)', e);
  }
  if (process.env.SEED_DEMO === 'true') {
    for (const u of [
      ['Expo Organizer','organizer@eventsphere.local','ExpoDemo123!','organizer'],
      ['Demo Attendee','attendee@eventsphere.local','ExpoDemo123!','attendee']
    ]) {
      const found = await pool.query('SELECT id FROM users WHERE email=$1',[u[1]]);
      if (!found.rowCount) await pool.query('INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,$4)',[u[0],u[1],await bcrypt.hash(u[2],10),u[3]]);
    }
  }
}
app.get('/health', asyncRoute(async (_req,res) => {
  await pool.query('SELECT 1');
  res.json({ status: 'ok', service: 'eventsphere-api', database: 'connected' });
}));
app.get('/metrics', asyncRoute(async (_req,res) => { res.set('Content-Type',register.contentType); res.end(await register.metrics()); }));
app.get('/api/events', asyncRoute(async (req,res) => {
  const { search='', category='', city='' } = req.query;
  const result = await pool.query(`${eventSelect} WHERE ($1='' OR title ILIKE '%'||$1||'%' OR artist ILIKE '%'||$1||'%') AND ($2='' OR category=$2) AND ($3='' OR city ILIKE '%'||$3||'%') ORDER BY event_date ASC`,[String(search).slice(0,100),String(category).slice(0,60),String(city).slice(0,100)]);
  res.json(result.rows);
}));
app.get('/api/events/:id', asyncRoute(async (req,res) => {
  const r = await pool.query(`${eventSelect} WHERE id=$1`,[req.params.id]);
  if (!r.rowCount) return res.status(404).json({error:'Event not found'});
  res.json(r.rows[0]);
}));
app.post('/api/auth/register', asyncRoute(async (req,res) => {
  const { name,email,password } = req.body || {};
  if (typeof name!=='string' || name.trim().length<2 || name.trim().length>100 || typeof email!=='string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || typeof password!=='string' || password.length<8 || password.length>100) return res.status(400).json({error:'Enter a name, valid email and password (8+ characters).'});
  try {
    const hash = await bcrypt.hash(password,10);
    const r = await pool.query("INSERT INTO users(name,email,password_hash) VALUES($1,$2,$3) RETURNING id,name,email,role",[name.trim(),email.toLowerCase(),hash]);
    res.status(201).json({ user:safeUser(r.rows[0]), token:signToken(r.rows[0]) });
  } catch(e) { if(e.code==='23505') return res.status(409).json({error:'An account with this email already exists.'}); throw e; }
}));
app.post('/api/auth/login', asyncRoute(async (req,res) => {
  const { email,password } = req.body || {};
  const r = await pool.query('SELECT * FROM users WHERE email=$1',[String(email||'').toLowerCase()]);
  if (!r.rowCount || !await bcrypt.compare(String(password||''),r.rows[0].password_hash)) return res.status(401).json({error:'Email or password is incorrect.'});
  res.json({user:safeUser(r.rows[0]),token:signToken(r.rows[0])});
}));
app.get('/api/auth/me',auth,(req,res)=>res.json({user:req.user}));
app.post('/api/bookings',auth,asyncRoute(async(req,res)=>{
  const eventId=Number(req.body?.eventId), quantity=Number(req.body?.quantity);
  if(!Number.isInteger(eventId)||!Number.isInteger(quantity)||quantity<1||quantity>8) return res.status(400).json({error:'Choose between 1 and 8 tickets.'});
  const db=await pool.connect();
  try {
    await db.query('BEGIN');
    const er=await db.query('SELECT * FROM events WHERE id=$1 FOR UPDATE',[eventId]);
    if(!er.rowCount){await db.query('ROLLBACK');return res.status(404).json({error:'Event not found.'});}
    const event=er.rows[0];
    if(new Date(event.event_date)<new Date()){await db.query('ROLLBACK');return res.status(400).json({error:'This event has already taken place.'});}
    if(event.available<quantity){await db.query('ROLLBACK');return res.status(409).json({error:'Not enough tickets remain. Please choose a smaller quantity.'});}
    const code=`ES-${randomUUID().replaceAll('-','').slice(0,12).toUpperCase()}`;
    const total=Number(event.price)*quantity;
    const br=await db.query('INSERT INTO bookings(user_id,event_id,quantity,total,ticket_code) VALUES($1,$2,$3,$4,$5) RETURNING *',[req.user.id,eventId,quantity,total,code]);
    await db.query('UPDATE events SET available=available-$1 WHERE id=$2',[quantity,eventId]);
    await db.query('COMMIT');
    bookingCounter.inc();
    const qr=await QRCode.toDataURL(JSON.stringify({ticketCode:code,eventId,bookingId:br.rows[0].id}));
    res.status(201).json({booking:{...br.rows[0],event,qr}});
  } catch(e){await db.query('ROLLBACK');throw e;} finally{db.release();}
}));
app.get('/api/bookings/mine',auth,asyncRoute(async(req,res)=>{
  const r=await pool.query(`SELECT b.id,b.quantity,b.total,b.ticket_code,b.checked_in_at,b.created_at,e.title,e.artist,e.venue,e.city,e.event_date,e.image_url FROM bookings b JOIN events e ON e.id=b.event_id WHERE b.user_id=$1 ORDER BY b.created_at DESC`,[req.user.id]);
  const rows=await Promise.all(r.rows.map(async b=>({...b,qr:await QRCode.toDataURL(JSON.stringify({ticketCode:b.ticket_code,bookingId:b.id}))})));
  res.json(rows);
}));
app.post('/api/bookings/:id/check-in',auth,roles('organizer','admin'),asyncRoute(async(req,res)=>{
  const r=await pool.query('UPDATE bookings SET checked_in_at=NOW() WHERE id=$1 AND ticket_code=$2 AND checked_in_at IS NULL RETURNING id,ticket_code,checked_in_at',[req.params.id,req.body?.ticketCode]);
  if(!r.rowCount) return res.status(409).json({error:'Ticket is invalid or has already been checked in.'});
  res.json({message:'Ticket checked in successfully.',booking:r.rows[0]});
}));
app.post('/api/events',auth,roles('organizer','admin'),asyncRoute(async(req,res)=>{
  const {title,artist,description,category,venue,city,eventDate,price,capacity,imageUrl}=req.body||{};
  if(![title,artist,description,category,venue,city,imageUrl].every(v=>typeof v==='string'&&v.trim())||!Number.isFinite(Number(price))||Number(price)<0||!Number.isInteger(Number(capacity))||Number(capacity)<1||!Number.isFinite(Date.parse(eventDate))) return res.status(400).json({error:'Complete all event fields with a valid date, price and capacity.'});
  const r=await pool.query('INSERT INTO events(title,artist,description,category,venue,city,event_date,price,capacity,available,image_url) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$9,$10) RETURNING *',[title,artist,description,category,venue,city,eventDate,price,capacity,imageUrl]);
  res.status(201).json(r.rows[0]);
}));
app.get('/api/admin/summary',auth,roles('organizer','admin'),asyncRoute(async(_req,res)=>{
  const [events,bookings,revenue,checkins]=await Promise.all([
    pool.query('SELECT COUNT(*)::int n FROM events'),
    pool.query('SELECT COUNT(*)::int n,COALESCE(SUM(quantity),0)::int tickets FROM bookings'),
    pool.query('SELECT COALESCE(SUM(total),0)::numeric(12,2) amount FROM bookings'),
    pool.query('SELECT COUNT(*)::int n FROM bookings WHERE checked_in_at IS NOT NULL')
  ]);
  res.json({events:events.rows[0].n,bookings:bookings.rows[0].n,tickets:bookings.rows[0].tickets,revenue:Number(revenue.rows[0].amount),checkins:checkins.rows[0].n});
}));
app.use((err,_req,res,_next)=>{console.error(err);res.status(500).json({error:'Something went wrong. Check API logs.'});});
await (async()=>{for(let i=0;i<20;i++){try{await pool.query('SELECT 1');await seed();return;}catch(e){if(i===19)throw e;await new Promise(r=>setTimeout(r,1500));}}})();
app.listen(port,'0.0.0.0',()=>console.log(`EventSphere API listening on ${port}`));
